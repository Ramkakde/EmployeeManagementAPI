using EmployeeAPI.Model;
using EmployeeRestAPI.Controllers;
using EmployeeRestAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace EmployeeRestAPI.Test
{
    [TestClass]
	public class EmployeeRestAPITest : IDisposable
    {
        #region 
        private Mock<ILogger<EmployeeController>> _mockLogger;
        private Mock<IEmployeeRepository> _mockEmployeeRepository;
        private IList<Employee> employeeData = new List<Employee>();
        private EmployeeController _controller;
        private bool disposed = false;
        #endregion
        
        [TestInitialize]
        public void Setup()
        {
            Initialise();
        }
        protected virtual void Initialise()
        {
            _mockLogger = new Mock<ILogger<EmployeeController>>();
            _mockEmployeeRepository = new Mock<IEmployeeRepository>();
            SetupData();
            GetController();
        }

        protected virtual void SetupData()
        {
            employeeData = new List<Employee>{
                        new Employee{ EmployeeId=1,FirstName="EmpFirstName1", MiddleName="MiddleName1",Surname="Surname1",EmailAddress="Emp1@gmail.com" },
                        new Employee{ EmployeeId=2,FirstName="EmpFirstName2", MiddleName="MiddleName2",Surname="Surname2",EmailAddress="Emp2@gmail.com" },
                        new Employee{ EmployeeId=3,FirstName="EmpFirstName3", MiddleName="MiddleName3",Surname="Surname3",EmailAddress="Emp3@gmail.com" },
            };
        }
        protected virtual void GetController()
        {
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.HttpContext.User = new ClaimsPrincipal(new GenericIdentity("Ramk","Admin"));
            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            _controller = new EmployeeController(_mockLogger.Object, _mockEmployeeRepository.Object)
            {
                ControllerContext = controllerContext
            };
        }

        /// <summary>
        /// Method to get all combo Employee List.
        /// </summary>
        [TestMethod]
        public void GetEmployeeList()
        {
            _mockEmployeeRepository.Setup(p => p.GetEmployeeList()).ReturnsAsync((List<Employee>)employeeData);
            var result = _controller.GetAll();
            Assert.IsNotNull(result);
        }
        /// <summary>
        /// Method to add Employee.
        /// </summary>
        [TestMethod]
        [DataRow(1)]
        public void AddEmployee(int EmployeeId)
        {
            Employee empObj = employeeData.FirstOrDefault(x => x.EmployeeId == EmployeeId);
            if (empObj != null)
            {
                _mockEmployeeRepository.Setup(e => e.CreateEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empObj);
                var postResult = _controller.Post(empObj) as Task<ActionResult<Employee>>;
                Assert.IsNotNull(postResult);
            }
        }

        /// <summary>
        /// Method to fail add Employee.
        /// </summary>
        [TestMethod]
        [DataRow("")]
        public void AddEmployeeFail(string EmployeeFirstName)
        {
            Employee empObj = employeeData.FirstOrDefault(x => x.FirstName == EmployeeFirstName);
            {
                _mockEmployeeRepository.Setup(e => e.CreateEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empObj);
                var postResult = _controller.Post(empObj) as Task<ActionResult<Employee>>;
                Assert.IsFalse(postResult==null, $"{EmployeeFirstName} should not be null or empty.");
            }
        }

        /// <summary>
        /// Method to Patch Employee.
        /// </summary>
        [TestMethod]
        public void PatchEmployee()
        {
            Employee empobj= employeeData.FirstOrDefault();
            _mockEmployeeRepository.Setup(x => x.PatchEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empobj);
            //Act
            var patchResult = _controller.Patch(empobj);
            //Assert
            Assert.IsNull(patchResult.Result.Value);
        }

        /// <summary>
        /// Method to Patch Employee Not Found.
        /// </summary>
        [TestMethod]
        [DataRow(100)]
        public void PatchEmployeeNotFound(int empid)
        {
            Employee empObj = employeeData.FirstOrDefault(x => x.EmployeeId == empid);
            _mockEmployeeRepository.Setup(x => x.PatchEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empObj);
            //Act
            var patchResult = _controller.Patch(empObj);
            //Assert
            Assert.IsFalse(patchResult == null, $"Somthing went wrong while update employee.");
        }


        /// <summary>
        /// Method to delete Employee with not found.
        /// </summary>
        [TestMethod]
        [DataRow(101)]
        public void DeleteEmployeeNotFound(int empid)
        {

            Employee empObj = employeeData.FirstOrDefault(x => x.EmployeeId == empid);
            if (empObj != null)
            {
                _mockEmployeeRepository.Setup(x => x.DeleteEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empObj);
                //Act
                var deleteResult = _controller.Delete(empObj.EmployeeId);
                //Assert
                Assert.IsFalse(deleteResult == null, $"Somthing went wrong while delete Emolpyee.");
            }
            else
            {
                Assert.IsFalse(false, $"Emolpyee not found.");
            }

        }

        /// <summary>
        /// Method to delete Employee.
        /// </summary>
        [TestMethod]
        public void DeleteEmployee()
        {
            Employee empobj = employeeData.FirstOrDefault();
            _mockEmployeeRepository.Setup(x => x.DeleteEmployee(It.IsAny<Employee>())).ReturnsAsync(() => empobj);
            //Act
            var deleteResult = _controller.Delete(empobj.EmployeeId);
            //Assert
            Assert.IsNull(deleteResult.Result.Value);
        }


        /// <summary>
        /// Method to dispose object.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        ///  Method to dispose object.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
        }
    }
}
