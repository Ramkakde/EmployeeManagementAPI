using EmployeeAPI.Model;
using EmployeeRestAPI.Controllers;
using EmployeeRestAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace EmployeeRestAPI.Test
{
    [TestClass]
	public class LoginRestAPITest : IDisposable
    {
        #region 
        private Mock<ILogger<LoginController>> _mockLogger;
        private Mock<ILoginRepository> _mockLoginRepository;
        private  User  loginDetails = new  User ();
        private LoginController _controller;
        private bool disposed = false;
        #endregion
        
        [TestInitialize]
        public void Setup()
        {
            Initialise();
        }
        protected virtual void Initialise()
        {
            _mockLogger = new Mock<ILogger<LoginController>>();
            _mockLoginRepository = new Mock<ILoginRepository>();
            SetupData();
            GetController();
        }

        protected virtual void SetupData()
        {
            loginDetails = new User { UserId = "Admin", Password = "Password@01" };
        }
        protected virtual void GetController()
        {
            var httpContext = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            httpContext.HttpContext.User = new ClaimsPrincipal(new GenericIdentity("Ramk","Admin"));
            var controllerContext = new ControllerContext()
            {
                HttpContext = httpContext,
            };
            _controller = new LoginController(_mockLogger.Object, _mockLoginRepository.Object)
            {
                ControllerContext = controllerContext
            };
        }

        /// <summary>
        /// Method to test Login 
        /// </summary>
        [TestMethod]
        [DataRow("SuperAdmin","Password@01")]
        public void LoginTest(string userId, string Password)
        {
            User loginuser = new User { UserId = userId, Password = Password };
            _mockLoginRepository.Setup(p => p.Login(loginuser));
            var result = _controller.Login(loginuser.UserId, loginuser.Password);
            Assert.IsNotNull(result);
        }

        /// <summary>
        /// Method to test Login 
        /// </summary>
        [TestMethod]
        [DataRow("xyz", "xyz")]
        public void LoginTestFailed(string userId, string Password)
        {
            User loginuser = new User { UserId = userId, Password = Password };
            _mockLoginRepository.Setup(p => p.Login(loginuser)).ReturnsAsync(() => loginDetails);
            var result = _controller.Login(loginuser.UserId, loginuser.Password);
            Assert.IsNull(result.Result.Value);
        }

        /// <summary>
        /// Method to dispose object.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        /// <summary>
        ///  Method to dispose object.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposed)
                return;
            disposed = true;
        }
    }
}
