﻿using AutoMapper;
using EmployeeAPI.Model;
using EmployeeRestAPI.DBContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Threading.Tasks;

namespace EmployeeRestAPI.AutoMapper
{
	 
    public class AutoMapperConfiguration : Profile
    {
        /// <summary>
        /// The AutoMapper configuration.
        /// </summary>
        public AutoMapperConfiguration()
        {
            CreateMap<EmployeeEntity, Employee>().ReverseMap();
            CreateMap<UserEntity, User>().ReverseMap();
        }
    }

}
