﻿using EmployeeAPI.Model;
using EmployeeRestAPI.Core;
using EmployeeRestAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
 

namespace EmployeeRestAPI.Controllers
{
	[ApiController]
	[Route("[controller]")]
	[TypeFilter(typeof(ApiHeaderAuthorizationAttribute))]
	public class EmployeeController : BaseController
	{
		private readonly ILogger<EmployeeController> _logger;
		private readonly IEmployeeRepository _iEmployeeRepository;
		public EmployeeController(ILogger<EmployeeController> logger, IEmployeeRepository iEmployeeRepository)
		{
			_logger = logger;
			_iEmployeeRepository = iEmployeeRepository;
		}

		/// <summary>
		/// API method to retrieve all employee.
		/// </summary>        
		/// <returns>returns employee list.</returns>
		/// <response code="200">The target resource was successfully retrieved.</response>
		/// <response code="400">The request was not valid.</response>
		/// <response code="401">The authentication credentials are not valid for the target resource.</response>
		/// <response code="404">The target resource does not exist.</response>
		[HttpGet]
		public async Task<ActionResult<IList<Employee>>> GetAll()
		{
			 
			IList<Employee> employeeList;
			string UserName = HttpContext.User.Identity.Name;
			string UserRoles = HttpContext.User.Identity.AuthenticationType;
			if (!string.IsNullOrEmpty(UserRoles))
			{
				switch (UserRoles.ToLower())
				{
					case "super":
						{
							employeeList = await _iEmployeeRepository.GetEmployeeList();
							if (employeeList?.Count() > 0)
								return Ok(employeeList);
						}
						break;
					case "admin":
						{
							employeeList = await _iEmployeeRepository.GetEmployeeList();
							if (employeeList?.Count() > 0)
								return Ok(employeeList.FirstOrDefault());
						}
						break;
					case "employee":
						{
							ModelState.AddModelError("User Access.", "Unauthorized access exception.");
							return BadRequest(ModelState);
						}
						break;
					default:
						break;
				}
			}
			return null;
			}

		/// <summary>
		/// API method to create a new employee.
		/// </summary>
		/// <param name="employee">This identifies the employee object.</param>
		/// <returns>returns Employee created.</returns>
		/// <response code="200">The target resource was successfully retrieved.</response>
		/// <response code="400">The request was not valid.</response>
		/// <response code="401">The authentication credentials are not valid for the target resource.</response>
		/// <response code="404">The target resource does not exist.</response>
		[HttpPost]
		public async Task<ActionResult<Employee>> Post([FromBody] Employee employee)
		{
			 
			if (employee is null)
			{
				throw new ArgumentNullException(nameof(employee));
			}
			ValidateRequest(employee);
			if (!ModelState.IsValid)
			{
				return BadRequest(ModelState);
			}

			await _iEmployeeRepository.CreateEmployee(employee).ConfigureAwait(false);
			return Ok(employee);
		}

		/// <summary>
		/// API method to update an existing employee.
		/// </summary>
		/// <param name="employee">This identifies the employee.</param>
		/// <returns>returns updated employee.</returns>
		/// <response code="200">The target resource was successfully retrieved.</response>
		/// <response code="400">The request was not valid.</response>
		/// <response code="401">The authentication credentials are not valid for the target resource.</response>
		/// <response code="404">The target resource does not exist.</response>
		[HttpPatch]
		public async Task<ActionResult<List<Employee>>> Patch([FromBody] Employee employee)
		{
			if (employee is null)
			{
				throw new ArgumentNullException(nameof(employee));
			}
			var patchResult = await _iEmployeeRepository.PatchEmployee(employee).ConfigureAwait(false);
			if (patchResult is null)
			{
				return NotFound();
			}
			return NoContent();
		}


		/// <summary>
		/// API method to delete an existing employee.
		/// </summary>
		/// <param name="employeeId">This identifies the employeeId.</param>
		/// <returns>returns not found if employee not exist or returns no content if successfull delete. </returns>
		/// <response code="200">The target resource was successfully retrieved.</response>
		/// <response code="400">The request was not valid.</response>
		/// <response code="401">The authentication credentials are not valid for the target resource.</response>
		/// <response code="404">The target resource does not exist.</response>
		[HttpDelete]
		public async Task<ActionResult<Employee>> Delete([Required]int employeeId)
		{
			if (employeeId<= 0)
			{
				throw new InvalidOperationException(nameof(employeeId));
			}

			Employee employee = new Employee { EmployeeId = employeeId };
			ValidateRequest(employee);
		
			if (!ModelState.IsValid)
			{
				return BadRequest(ModelState);
			}
			var deleteEmployee = await _iEmployeeRepository.DeleteEmployee(employee).ConfigureAwait(false);
			if (deleteEmployee is null)
			{
				return NotFound();
			}
			return NoContent();
		}


		/// <summary>
		/// This method is used to validate employee details.
		/// </summary>
		/// <param name="employee">This identifies the employee.</param>

		private void ValidateRequest(Employee employee)
		{
			if (Request.Method.ToLower()=="post" &&  employee != null)
			{
				if (employee.EmployeeId>0)
				{
					ModelState.AddModelError("AddEmployee.", "EmployeeId Cannot be pass while Add");
				}
			}

			if (Request.Method.ToLower() == "delete" && employee != null)
			{
				if (employee.EmployeeId <= 0)
				{
					ModelState.AddModelError("DeleteEmployee.", "Invalid EmployeeId.");
				}
			}

		}
	}
}
 