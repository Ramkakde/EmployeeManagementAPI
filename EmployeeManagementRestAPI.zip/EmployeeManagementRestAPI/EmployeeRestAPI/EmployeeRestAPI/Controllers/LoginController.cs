﻿using EmployeeAPI.Model;
using EmployeeRestAPI.Core;
using EmployeeRestAPI.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
 

namespace EmployeeRestAPI.Controllers
{
	[AllowAnonymous]
	[ApiController]
	[Route("[controller]")]
	public class LoginController : ControllerBase
	{
		private readonly ILogger<LoginController> _logger;
		private readonly ILoginRepository _iLoginRepository;
		public LoginController(ILogger<LoginController> logger, ILoginRepository iLogin)
		{
			_logger = logger;
			_iLoginRepository = iLogin;
		}

		/// <summary>
		/// API method to validate user credintials.
		/// </summary>
		/// <param name="UserID">This identifies the UserID object.</param>
		/// <param name="Password">This identifies the Password object.</param>
		/// <returns>returns Validated User.</returns>
		/// <response code="200">The target resource was successfully retrieved.</response>
		/// <response code="400">The request was not valid.</response>
		/// <response code="401">The authentication credentials are not valid for the target resource.</response>
		/// <response code="404">The target resource does not exist.</response>
		[AllowAnonymous]
		[HttpGet]
		public async Task<ActionResult<User>>Login([Required]string UserID, [Required]string Password)
		{
			if (UserID is null || Password is null)
			{
				throw new ArgumentNullException();
			}
			var loginDetails = new User { UserId = UserID, Password = Password };
			loginDetails = await _iLoginRepository.Login(loginDetails).ConfigureAwait(false);
			if (loginDetails != null)
			{
				return Ok(loginDetails);
			}
			else
			{
				ModelState.AddModelError("Unauthorized.", "Invalid Userid & Password");
				return BadRequest(ModelState);
			}
		}
 
	}
}
 