﻿using EmployeeRestAPI.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using System;
using System.Globalization;

namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// A filter that asynchronously surrounds execution of the action and the action result.
    /// </summary>
    /// <remarks>
    /// This class supports dependency injection: see https://weblog.west-wind.com/posts/2016/Oct/16/Error-Handling-and-ExceptionFilter-Dependency-Injection-for-ASPNET-Core-APIs.
    /// </remarks>
    public class ApiActionFilterAttribute : ActionFilterAttribute
    {
        private readonly ILogger<ApiActionFilterAttribute> _logger;

        /// <summary>
        ///  Constructs an instance of the ApiActionFilterAttribute object.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public ApiActionFilterAttribute(ILogger<ApiActionFilterAttribute> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Called after the action executes, before the action result.
        /// </summary>
        /// <param name="context">The Microsoft.AspNetCore.Mvc.Filters.ActionExecutedContext.</param>
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            if (context is null)
            {
                throw new ArgumentNullException(nameof(context));
            }
            if (!context.Canceled && context.Exception == null)
            {
                var statusCodeResult = context.Result as StatusCodeResult;
                if (statusCodeResult?.StatusCode >= 400 && statusCodeResult?.StatusCode < 500)
                {
                    // An HTTP status error has occurred. 
                    var errorResult = new ErrorResult(statusCodeResult.StatusCode.ToString(CultureInfo.InvariantCulture), ReasonPhrases.GetReasonPhrase(statusCodeResult.StatusCode), _logger);

                    const string result = "Result";
                    const string objectResult = "ObjectResult";
                    Type existingType = context.Result.GetType();
                    string existingTypeName = existingType.FullName;
                    IActionResult newActionResult = null;
                    if (existingTypeName.EndsWith(result, StringComparison.InvariantCultureIgnoreCase) && !existingTypeName.EndsWith(objectResult, StringComparison.InvariantCultureIgnoreCase))
                    {
                        // Type is a Result but not an ObjectResult, so convert it into the equivalent ObjectResult.
                        string newTypeName = $"{existingTypeName.Substring(0, existingTypeName.Length - result.Length)}{objectResult}";
                        Type newType = existingType.Assembly.GetType(newTypeName);
                        if (newType != null)
                        {
                            var constructor = newType.GetConstructor(new[] { typeof(object) });
                            if (constructor != null)
                            {
                                newActionResult = (IActionResult)constructor.Invoke(new object[] { errorResult });
                            }
                        }
                    }

                    if (newActionResult is null)
                    {
                        newActionResult = new UnprocessableEntityObjectResult(errorResult);
                    }

                    context.Result = newActionResult;
                }
            }
        }
    }
}
