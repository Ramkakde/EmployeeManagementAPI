﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;

namespace EmployeeRestAPI.Core 
{
    /// <summary>
    /// A filter that runs asynchronously after an action has thrown an Exception.
    /// </summary>
    /// <remarks>
    /// This class supports dependency injection: see https://weblog.west-wind.com/posts/2016/Oct/16/Error-Handling-and-ExceptionFilter-Dependency-Injection-for-ASPNET-Core-APIs.
    /// </remarks>
    public class ApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        //private readonly IStringLocalizer _localizer;
        private readonly ILogger<ApiExceptionFilterAttribute> _logger;

        /// <summary>
        ///  Creates a new ApiExceptionFilterAttribute.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public ApiExceptionFilterAttribute(ILogger<ApiExceptionFilterAttribute> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Handler for exception events.
        /// </summary>
        /// <param name="context">The context for the exception.</param>
        /// <remarks>
        /// This handler will automatically be called for any unhandled exception that is thrown by a controller that inherits from Controllers 
        /// The runtime already automatically logs unhandled exceptions, so there is no need to log them again here.
        /// </remarks>
        public override void OnException(ExceptionContext context)
        {
            if (context is null)
            {
                throw new ArgumentNullException(nameof(context));
            }
            context.Result = new UnprocessableEntityObjectResult(new ExceptionErrorResult(context.Exception, _logger));
        }
    }
}
