﻿using EmployeeAPI.Model;
using EmployeeRestAPI.Core;
using EmployeeRestAPI.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;

namespace EmployeeRestAPI.Core
{
	/// <summary>
	/// This Attribute is to authorize Apis.
	/// </summary>
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
	public sealed class ApiHeaderAuthorizationAttribute : Attribute, IAuthorizationFilter
	{
		/// <summary>
		/// The UserId Key constant.
		/// </summary>
		public static string AuthorizationKeyName { get; } = "Token";
		/// <summary>
		/// The UserId Key constant.
		/// </summary>
		public static string UserIdKeyName { get; } = "userId";
		/// <summary>
		/// The Password Key constant.
		/// </summary>
		public static string PasswordKeyName { get; } = "Password";

		/// <summary>
		/// Authorize User Id of either internal or 3rd party.
		/// </summary>
		/// <param name="filterContext">The filtercontext.</param>
		public void OnAuthorization(AuthorizationFilterContext filterContext)
		{
			try
			{
				if (filterContext != null)
				{
					if (filterContext.HttpContext.Request.Headers.ContainsKey(AuthorizationKeyName))
					{
						var LoginUser = new User();

						string authHeader = filterContext.HttpContext.Request.Headers[AuthorizationKeyName];
						if (authHeader != null && authHeader.StartsWith("Basic"))
						{
							string encodedUsernamePassword = authHeader.Substring("Basic ".Length).Trim();
							Encoding encoding = Encoding.GetEncoding("iso-8859-1");
							string usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));
							int seperatorIndex = usernamePassword.IndexOf(':');
							string userId = usernamePassword.Substring(0, seperatorIndex);
							string Password = usernamePassword.Substring(seperatorIndex + 1);
							LoginUser = EmployeeSecurity.Login(userId, Password);
							if (userId.Length == 0 || userId.Length > 64)
							{
								filterContext.Result = new BadRequestObjectResult(new ErrorResult($"{ErrorCode.UserIdKeyMissing + " or " + ErrorCode.PasswordKeyMissing}", null, null));
							}
							else if (filterContext.HttpContext.User?.Identity?.Name == null)
							{
								if (LoginUser != null)
								{
									filterContext.HttpContext.User = new ClaimsPrincipal(new GenericIdentity(LoginUser.UserId, LoginUser.Role));
								}
								else
								{
									filterContext.Result = new BadRequestObjectResult(new ErrorResult($"{ErrorCode.Unauthorized}", null, null));
								}
							}
						}
						else
						{
							filterContext.Result = new BadRequestObjectResult(new ErrorResult($"{ErrorCode.Unauthorized}", null, null));
						}
					}
					else
					{
						filterContext.Result = new BadRequestObjectResult(new ErrorResult($"{AuthorizationKeyName} is missing.", null, null));
					}
				}
			}
			catch (Exception ex)
			{
				filterContext.Result = new BadRequestObjectResult(new ErrorResult($"{ErrorCode.Unauthorized}, \n " + ex.Message, null, null));
			}
		}
	}
}