﻿namespace EmployeeRestAPI.Core
{
	/// <summary>
	/// AppSettings - Get values from appSettings.config file
	/// </summary>
	public static class AppSettings
	{
		/// <summary>
		/// Username
		/// </summary>
		public static string UserName { get; set; }
		/// <summary>
		/// Password
		/// </summary>
		public static string Password { get; set; }
		/// <summary>
		/// EmployeeApiContext
		/// </summary>
		public static string EmployeeApiContext { get; set; }
		/// <summary>
		/// UserId.
		/// </summary>
		public static string UserId { get; set; }

	}
}
