﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// Base class for controllers.
    /// </summary>
    /// <remarks>
    /// Inherits from Microsoft.AspNetCore.Mvc.ControllerBase and not Microsoft.AspNetCore.Mvc.Controller, 
    /// as REST Web APIs do not need the support for Views that is in Microsoft.AspNetCore.Mvc.Controller.
    /// Uses the ApiActionFilterAttribute to automatically filter any action for this controller.
    /// Uses the ApiExceptionFilterAttribute to automatically handle any exception that is thrown by this controller.
    /// </remarks>
    [ApiController]
    [ServiceFilter(typeof(ApiActionFilterAttribute))]
    [ServiceFilter(typeof(ApiExceptionFilterAttribute))]
    public class BaseController : ControllerBase
    {
        /// <summary>
        /// The logger.
        /// </summary>
        protected ILogger Logger { get; }

        /// <summary>
        /// Creates a new BaseController.
        /// </summary>
        public BaseController()
        {
            
        }
       
        [NonAction]
        public override BadRequestObjectResult BadRequest(ModelStateDictionary modelState) => 
            // Format as a InvalidModelStateErrorResult.
            new BadRequestObjectResult(new InvalidModelStateErrorResult(ControllerContext));
    }


    /// <summary>
    /// Represents a invalid model state error result, e.g., validation errors.
    /// </summary>
    public class InvalidModelStateErrorResult  
    {
        /// <summary>
        /// Creates a new InvalidModelStateErrorResult.
        /// </summary>
        /// <param name="actionContext">The action context.</param>
        public InvalidModelStateErrorResult(ActionContext actionContext)  
        {
        }
    }
}
