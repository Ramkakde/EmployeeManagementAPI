﻿using EmployeeRestAPI.Core;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// Represents an error result as defined in Microsoft's REST API Guidelines: https://github.com/Microsoft/api-guidelines/blob/vNext/Guidelines.md#7102-error-condition-responses.
    /// </summary>
    public class BaseErrorResult 
    {
        /// <summary>
        /// The error object.
        /// </summary>
        [Required]
        public Error Error { get; set; }

        /// <summary>
        /// Creates a new ErrorResult.
        /// </summary>
        /// <param name="error">The error.</param>
        public BaseErrorResult(Error error)
        {
            Error = error;
        }
    }
}
