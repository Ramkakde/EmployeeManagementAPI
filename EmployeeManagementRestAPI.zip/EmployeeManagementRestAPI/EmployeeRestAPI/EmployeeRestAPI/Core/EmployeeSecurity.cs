﻿using EmployeeAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeRestAPI.Core
{
	public class EmployeeSecurity
	{
		public static User Login(string userID, string password)
		{
			using (DBEntity.EmployeeDBContext empdb = new DBEntity.EmployeeDBContext())
			{
				var  _userEntity = empdb.UserEntity.Where(user => user.UserId==userID && user.Password == password).FirstOrDefault();
				if (_userEntity != null)
				{
					return new User
					{
						UserId = _userEntity.UserId,
						Password = _userEntity.Password,
						Role = _userEntity.Role
					};
				}
				return null;
			}
		}

		public static string Base64Encode(string textToEncode)
		{

			byte[] textAsBytes = Encoding.UTF8.GetBytes(textToEncode);
			return Convert.ToBase64String(textAsBytes);
		}
	}
}
