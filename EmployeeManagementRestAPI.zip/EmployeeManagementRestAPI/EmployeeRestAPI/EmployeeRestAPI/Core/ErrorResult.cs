﻿using Microsoft.Extensions.Logging;
using System;

namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// Represents an error result as defined in Microsoft's REST API Guidelines: https://github.com/Microsoft/api-guidelines/blob/vNext/Guidelines.md#7102-error-condition-responses.
    /// </summary>
    public class ErrorResult : BaseErrorResult
    {
        /// <summary>
        /// Creates a new ErrorResult.
        /// </summary>
        /// <param name="code">The service-defined error code that should be human-readable.</param>
        /// <param name="message">A human-readable representation of the error.</param>
        /// <param name="logger">The logger.</param>
        public ErrorResult(string code, string message, ILogger logger = null) : this(new Error(code, message), null, logger)
        {
        }

        /// <summary>
        /// Creates a new ErrorResult.
        /// </summary>
        /// <param name="code">The service-defined error code that should be human-readable.</param>
        /// <param name="message">A human-readable representation of the error.</param>
        /// <param name="exception">The associated exception to log.</param>
        /// <param name="logger">The logger.</param>
        public ErrorResult(string code, string message, Exception exception = null, ILogger logger = null) : this(new Error(code, message), exception, logger)
        {
        }

        /// <summary>
        /// Creates a new ErrorResult.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <param name="logger">The logger.</param>
        public ErrorResult(Error error, ILogger logger = null) : this(error, null, logger)
        {
        }
        
        /// <summary>
        /// Creates a new ErrorResult.
        /// </summary>
        /// <param name="error">The error.</param>
        /// <param name="exception">The associated exception to log.</param>
        /// <param name="logger">The logger.</param>
        public ErrorResult(Error error, Exception exception = null, ILogger logger = null) : base(error)
        {
            if (error is null)
            {
                throw new ArgumentNullException(nameof(error));
            }
            if (logger != null && logger.IsEnabled(LogLevel.Error))
            {
                if (exception != null)
                {
                    logger.LogError(exception, error.ToString());
                }
                else
                {
                    logger.LogError(error.ToString());
                }
            }
        }
    }
   
    /// <summary>
    /// Represents error codes.
    /// </summary>
    public static class ErrorCode
    {
        /// <summary>
        /// InternalError.
        /// </summary>
        public const string InternalError = nameof(InternalError);
        /// <summary>
        /// ApiKeyMissing.
        /// </summary>
        public const string UserIdKeyMissing = nameof(UserIdKeyMissing);

        /// <summary>
        /// ApiKeyMissing.
        /// </summary>
        public const string PasswordKeyMissing = nameof(PasswordKeyMissing);

        /// <summary>
        /// InValidUserIdOrPassword.
        /// </summary>
        public const string InValidUserIdOrPassword = nameof(InValidUserIdOrPassword);
        /// <summary>
        /// Unauthorized.
        /// </summary>
        public const string Unauthorized = nameof(Unauthorized);
    }
}
