﻿using EmployeeRestAPI.Core;
using Microsoft.Extensions.Localization;
using System;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;
namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// Represents an exception error.
    /// </summary>
    public class ExceptionError : Error
    {
        /// <summary>
        /// Creates a new ExceptionError object from an existing exception object.
        /// </summary>
        /// <param name="exception">The exception object.</param>
       
        public ExceptionError(Exception exception) : base(exception?.GetType().ToString())
        {
            Message = GetErrorMessage(exception);
            InnerError = CreateInnerError(exception);
        }

        /// <summary>
        /// Creates a new ExceptionError object from an existing Error object.
        /// </summary>
        /// <param name="error">The error object.</param>
        public ExceptionError(Error error) : base(error?.Code, error?.Message, error?.Target, error?.Details, error?.InnerError)
        {
        }

        private Error CreateInnerError(Exception exception)
        {
            Error innerError = null;

            if (exception.InnerException != null)
            {
                innerError = new Error(exception.InnerException.GetType().ToString(), GetErrorMessage(exception.InnerException), null, null, CreateInnerError(exception.InnerException));
            }

            return innerError;
        }

        private static string GetErrorMessage(Exception exception)
        {
            return exception.Message; 
        }
    }

    /// <summary>
    /// Represents an error in an error 
    /// </summary>
    public class Error
    {
        [Required]
        public string Code { get; set; }

        [Required]
        public string Message { get; set; }

        /// <summary>
        /// The target of the particular error (e.g., the name of the property in the error).
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Target { get; set; }

        /// <summary>
        /// The distinct, related errors that occurred during the request.
        /// </summary>
        /// <remarks>
        /// </remarks>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]

        public Error[] Details { get; set; }
        /// <summary>
        /// An inner error.
        /// </summary>
        /// <remarks>
        /// The contents of InnnerError are service-defined. Services wanting to return more specific errors than the root-level code MUST do so by including the Coe and 
        /// an InnerError. Each InnerError represents a higher level of detail than its parent. When evaluating errors, clients MUST traverse through all of the nested InnerErrors
        /// and choose the deepest one that they understand. This scheme allows services to introduce new error codes anywhere in the hierarchy without breaking backwards compatibility, 
        /// so long as old error codes still appear. The service MAY return different levels of depth and detail to different callers. For example, in development environments, 
        /// the deepest InnerError MAY contain internal information that can help debug the service. To guard against potential security concerns around information disclosure, 
        /// services SHOULD take care not to expose too much detail unintentionally. Error objects MAY also include custom server-defined properties that MAY be specific to the 
        /// Code. Error types with custom server-defined properties SHOULD be declared in the service's metadata document.
        /// </remarks>
        [JsonProperty(PropertyName = "innererror", NullValueHandling = NullValueHandling.Ignore)]
        public Error InnerError { get; set; }

        /// <summary>
        /// The unique identifier for this error.
        /// </summary>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Id { get; set; }

        /// <summary>
        /// Creates a new Error object.
        /// </summary>
        /// <param name="code">The service-defined error code that should be human-readable.</param>
        /// <param name="message">A human-readable representation of the error.</param>
        /// <param name="target">The target of the particular error (e.g., the name of the property in the error).</param>
        /// <param name="details">The distinct, related errors that occurred during the request.</param>
        /// <param name="innerError">The contents of this object are service-defined.</param>
        public Error(string code, string message = null, string target = null, Error[] details = null, Error innerError = null)
        {
            Code = code;
            Message = message;
            Target = target;
            Details = details;
            InnerError = innerError;
            Id = Guid.NewGuid().ToString();
        }
    }
}
