﻿using EmployeeRestAPI.Core;
using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using System;

namespace EmployeeRestAPI.Core
{
    /// <summary>
    /// Represents an exception error result.
    /// </summary>
    public class ExceptionErrorResult : BaseErrorResult
    {
        /// <summary>
        /// Creates a new ExceptionErrorResult.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="logger">The logger.</param>
        public ExceptionErrorResult(Exception exception, ILogger logger = null) : base(new ExceptionError(exception))
        {
            if (logger != null && logger.IsEnabled(LogLevel.Error))
                logger.LogError(exception, Error.ToString());
        }
    }
}
