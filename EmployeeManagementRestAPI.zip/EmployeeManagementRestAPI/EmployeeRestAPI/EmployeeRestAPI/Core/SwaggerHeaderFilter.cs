﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch.Operations;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeRestAPI.Core
{
	/// <summary>
	/// Operation filter to add the requirement of the custom header
	/// </summary>
	public class SwaggerHeaderFilter : IOperationFilter
	{
		/// <summary>
		/// Apply
		/// </summary>
		/// <param name="operation"></param>
		/// <param name="context"></param>
		public void Apply(OpenApiOperation operation, OperationFilterContext context)
		{
			if (context.MethodInfo.Name!="Login")
			{
				if (operation is null)
				{
					throw new ArgumentNullException(nameof(operation));
				}
				if (operation.Parameters == null)
					operation.Parameters = new List<OpenApiParameter>();
				operation.Parameters.Add(new OpenApiParameter
				{
					Name = "Token",
					In = ParameterLocation.Header,
					Schema = new OpenApiSchema { Type = "string", Default = new OpenApiString("Basic U3VwZXJBZG1pbjpQYXNzd29yZEAwMQ==") },
					Required = true
				});
			}
		}
	}
}

