﻿using EmployeeRestAPI.Core;
using EmployeeRestAPI.DBContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeRestAPI.DBEntity
{
	public class EmployeeDBContext : DbContext
	{
		public EmployeeDBContext() { }
		public EmployeeDBContext(DbContextOptions<EmployeeDBContext> options)
			: base(options)
		{
		}
		public virtual DbSet<EmployeeEntity> Employee { get; set; }
		public virtual DbSet<UserEntity> UserEntity { get; set; }
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			if (!optionsBuilder.IsConfigured)
			{
				optionsBuilder.UseSqlServer(AppSettings.EmployeeApiContext); 
			}
		}
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");
			modelBuilder.Entity<EmployeeEntity>().HasKey(employee => new { employee.EmployeeId });
			modelBuilder.Entity<UserEntity>().HasKey(user => new { user.UserId });
		}
	}
}
