﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeRestAPI.DBContext
{
	[Table("Employee")]
	public class EmployeeEntity
	{
		/// <summary>
		/// EmployeeId
		/// </summary>
		[MaxLength(12)]
		[Column("EmployeeId")]
		public int EmployeeId { get; set; }
		/// <summary>
		/// FirstName
		/// </summary>
		[Column("FirstName")]
		public string FirstName { get; set; }
		/// <summary>
		/// MiddleName
		/// </summary>
		[Column("MiddleName")] 
		public string MiddleName { get; set; }
		/// <summary>
		///  Surname
		/// </summary>
		[MaxLength(40)]
		[Column("Surname")] 
		public string Surname { get; set; }
		/// <summary>
		///  EmailAddress
		/// </summary>
		[MaxLength(100)]
		[Column("EmailAddress")] 
		public string EmailAddress { get; set; }
		/// <summary>
		///  IsDeleted
		/// </summary>
		[Column("IsDeleted")]
		public bool IsDeleted { get; set; }
	}
}
