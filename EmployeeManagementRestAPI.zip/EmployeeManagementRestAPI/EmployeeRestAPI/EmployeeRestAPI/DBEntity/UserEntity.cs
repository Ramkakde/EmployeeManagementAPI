﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeRestAPI.DBContext
{
	/// <summary>
	/// UserId
	/// </summary>
	[Table("LoginDetails")]
	public class UserEntity
	{
		/// <summary>
		/// UserId
		/// </summary>
		[Column("UserId")]
		public string UserId { get; set; }
		/// <summary>
		/// Password
		/// </summary>
		[Column("Password")]
		public string Password { get; set; }

		/// <summary>
		/// UserRole
		/// </summary> 
		public string Role { get; set; }
	}
}