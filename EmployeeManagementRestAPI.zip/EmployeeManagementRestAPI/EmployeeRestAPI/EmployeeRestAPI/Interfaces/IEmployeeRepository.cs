﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.Model;
namespace EmployeeRestAPI.Interfaces
{
	/// <summary>
	/// This is Employee Interface.
	/// </summary>
	public interface IEmployeeRepository
	{

		/// <summary>
		/// This will return whether application is exists or not.
		/// </summary>
		/// <returns></returns>
		Task<List<Employee>> GetEmployeeList();

		/// <summary>
		/// This method allows the user to create new employee.
		/// </summary>
		/// <param name="employee">The employee request object.</param>
		/// <returns>returns newly created employee.</returns>
		Task<Employee> CreateEmployee(Employee employee);

		/// <summary>
		/// This method allows the user to update Employee details.
		/// </summary>
		/// <param name="employee">The Employee request object.</param>
		/// <returns>returns updated Employee.</returns>
		Task<Employee> PatchEmployee(Employee employee);

		/// <summary>
		/// This method allows the user to delete Employee.
		/// </summary>
		/// <param name="employee"></param>
		/// <returns>return Employee object if exist or null if not found. </returns>
		Task<Employee> DeleteEmployee(Employee employee);
	}
}
