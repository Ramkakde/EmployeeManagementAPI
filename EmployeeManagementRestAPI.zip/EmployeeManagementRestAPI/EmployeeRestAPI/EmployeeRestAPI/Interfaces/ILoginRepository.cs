﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.Model;
namespace EmployeeRestAPI.Interfaces
{
	/// <summary>
	/// This is Employee Interface.
	/// </summary>
	public interface ILoginRepository
	{

		/// <summary>
		/// Login.
		/// </summary>
		/// <returns></returns>
		Task<User> Login(User loginUser);
		 
	}
}
