﻿using EmployeeRestAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.Model;
using EmployeeRestAPI.DBContext;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using System.Transactions;
using System.Reflection;
using EmployeeRestAPI.DBEntity;

namespace EmployeeRestAPI.Repositories
{
	/// <summary>
	/// EmployeeRepository.
	/// </summary>
	public class EmployeeRepository : IEmployeeRepository
	{
		private readonly EmployeeDBContext _dbContext;
		private readonly IMapper _mapper;
		/// <summary>
		/// This method allows the user to retrieve all Employee. 
		/// </summary>		

		public EmployeeRepository(EmployeeDBContext dbContext, IMapper mapper)
		{
			_dbContext = dbContext;
			_mapper = mapper;
		}

		/// <summary>
		/// This method allows the user to get all employee.
		/// </summary>
		/// <returns>returns all employee.</returns>
		public async Task<List<Employee>> GetEmployeeList()
		{
			List<Employee> employeeList = new List<Employee>();
			var emplist = await _dbContext.Employee.Where(e=> e.IsDeleted==false)
								 .AsNoTracking()
								  .ToListAsync()
								  .ConfigureAwait(false);
			if (emplist?.Count > 0)
				_mapper.Map(emplist, employeeList);
			return employeeList;
		}

		/// <summary>
		/// This method allows the user to create new employee.
		/// </summary>
		/// <param name="employee">The employee request object.</param>
		/// <returns>returns newly created employee.</returns>
		public async Task<Employee>CreateEmployee(Employee employee)
		{
			EmployeeEntity employeeEntity = _mapper.Map<EmployeeEntity>(employee);
			if (employeeEntity != null)
			{
				using (TransactionScope transactionScope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted }, TransactionScopeAsyncFlowOption.Enabled))
				{
					_dbContext.Employee.Add(employeeEntity);
					await _dbContext.SaveChangesAsync().ConfigureAwait(false);
					transactionScope.Complete();
				}
			}
			return employee;
		}


		/// <summary>
		/// This method allows the user to update Employee details.
		/// </summary>
		/// <param name="employee">The Employee request object.</param>
		/// <returns>returns updated Employee.</returns>
		public async Task<Employee> PatchEmployee(Employee employee)
		{
			EmployeeEntity existingEmployee = null;

			using (TransactionScope transactionScope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted }, TransactionScopeAsyncFlowOption.Enabled))
			{
				existingEmployee = await _dbContext.Employee
									.Where(t => t.EmployeeId == employee.EmployeeId)
									.FirstOrDefaultAsync()
									.ConfigureAwait(false);
				if (existingEmployee == null)
				{
					return null;
				}

				// Loop through all properties of the update model
				foreach (PropertyInfo prop in employee.GetType().GetProperties())
				{
					// If they are not null, update the property on the database model
					if (prop.GetValue(employee) != null)
					{
						existingEmployee
							.GetType()
							.GetProperty(prop.Name)
							.SetValue(existingEmployee, prop.GetValue(employee));
					}
				}
				 await _dbContext.SaveChangesAsync().ConfigureAwait(false);
				//await _dbContext.SaveChangesAsync().ConfigureAwait(false);
				  transactionScope.Complete();
			}
			return employee;

		}


		/// <summary>
		/// This method allows the user to delete Employee.
		/// </summary>
		/// <param name="Employee"></param>
		/// <returns>return Employee object if exist or null if not found. </returns>
		public async Task<Employee> DeleteEmployee(Employee employee)
		{
			Employee _employee = null;
			using (TransactionScope transactionScope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.ReadCommitted }, TransactionScopeAsyncFlowOption.Enabled))
			{
				var existingEmployee = await _dbContext.Employee
									.Where(t => t.EmployeeId == employee.EmployeeId)
									.FirstOrDefaultAsync()
									.ConfigureAwait(false);
				if (existingEmployee == null)
				{
					return null;
				}
				existingEmployee.IsDeleted = true;
				_employee = _mapper.Map(existingEmployee, _employee);
				await _dbContext.SaveChangesAsync().ConfigureAwait(false);
				transactionScope.Complete();
			}
			return _employee;

		}

	}
}
