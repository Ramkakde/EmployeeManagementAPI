﻿using EmployeeRestAPI.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeeAPI.Model;
using EmployeeRestAPI.DBContext;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using System.Transactions;
using System.Reflection;
using EmployeeRestAPI.DBEntity;
using EmployeeRestAPI.Core;

namespace EmployeeRestAPI.Repositories
{
	/// <summary>
	/// EmployeeRepository.
	/// </summary>
	public class LoginRepository : ILoginRepository
	{
		private readonly EmployeeDBContext _dbContext;
		private readonly IMapper _mapper;
		/// <summary>
		/// This method allows the user to retrieve all Employee. 
		/// </summary>		

		public LoginRepository(EmployeeDBContext dbContext, IMapper mapper)
		{
			_dbContext = dbContext;
			_mapper = mapper;
		}

		/// <summary>
		/// API method to validate user credintials.
		/// </summary>
		/// <returns>returns Validated User.</returns>
		public async Task<User>Login(User logindetails)
		{
			return EmployeeSecurity.Login(logindetails.UserId, logindetails.Password);
		}
	}
}
